/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * 
 */
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ClaseRegistroErrores {
    private BufferedWriter writer;

    public ClaseRegistroErrores(String logFileName) {
        try {
            this.writer = new BufferedWriter(new FileWriter(logFileName));
        } catch (IOException e) {
            System.out.println("Error al crear el archivo de log: " + e.getMessage());
        }
    }

    public void escribirLinea(int lineNumber, String line) {
        try {
            writer.write(String.format("%03d %s\n", lineNumber, line));
        } catch (IOException e) {
            System.out.println("Error escribiendo la línea en el archivo de log: " + e.getMessage());
        }
    }

    // Método para escribir errores solo al final, con una división antes
    public void escribirErroresAlFinal(List<String> errores) {
        try {
            // Línea divisoria de asteriscos
            writer.write("\n********** RESUMEN DE ERRORES **********\n");
            for (String error : errores) {
                writer.write(error + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error escribiendo el resumen de errores: " + e.getMessage());
        }
    }

    public void escribirTokens(int[] tokenCounts) {
        try {
            writer.write("\nTOKEN DE OPERADORES DE COMPARACIÓN:\n");
            writer.write(tokenCounts[0] + " Token ==\n");
            writer.write(tokenCounts[1] + " Token !=\n");
            writer.write(tokenCounts[4] + " Token <\n");
            writer.write(tokenCounts[5] + " Token >\n");
            writer.write(tokenCounts[2] + " Token <=\n");
            writer.write(tokenCounts[3] + " Token >=\n");
        } catch (IOException e) {
            System.out.println("Error escribiendo los tokens de operadores de comparación: " + e.getMessage());
        }
    }

    public void escribirComentariosFinal(int comentarioCount) {
        try {
            writer.write("\n" + comentarioCount + " líneas de comentario.\n");
            writer.close();  // Cierra el archivo al final
        } catch (IOException e) {
            System.out.println("Error escribiendo los comentarios: " + e.getMessage());
        }
    }
}



