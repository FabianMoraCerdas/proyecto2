import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class LecturaArchivos {
    private String pyFileName;
    private List<String> errores = new ArrayList<>();

    public LecturaArchivos(String pyFileName) {
        this.pyFileName = pyFileName;
    }

    public void procesarArchivo() {
        File pyFile = new File(pyFileName);

        if (!pyFile.exists() || !pyFileName.endsWith(".py")) {
            System.out.println("El archivo proporcionado no es válido o no es un archivo .py.");
            return;
        }

        String logFileName = pyFileName.replace(".py", "-errores.log");
        ClaseRegistroErrores logGenerator = new ClaseRegistroErrores(logFileName);

        try (BufferedReader reader = new BufferedReader(new FileReader(pyFile))) {
            String line;
            int lineNumber = 1;
            int comentarioCount = 0;
            int[] tokenCounts = new int[6];
            boolean importFound = false;

            while ((line = reader.readLine()) != null) {
                logGenerator.escribirLinea(lineNumber, line);

                if (line.contains("import")) {
                    if (!importFound && lineNumber > 1) {
                        String error = "Error 200. Línea " + lineNumber + ". El import no está al inicio del código.";
                        errores.add(error);
                    }
                    importFound = true;
                }

                if (line.trim().startsWith("#")) {
                    comentarioCount++;
                }

                if (line.contains("==")) tokenCounts[0]++;
                if (line.contains("!=")) tokenCounts[1]++;
                if (line.contains("<=")) tokenCounts[2]++;
                if (line.contains(">=")) tokenCounts[3]++;
                if (line.contains("<") && !line.contains("<=")) tokenCounts[4]++;
                if (line.contains(">") && !line.contains(">=")) tokenCounts[5]++;

                if (line.contains("=")) {
                    String[] partes = line.split("=");
                    String identificador = partes[0].trim();

                    if (identificador.contains(",")) {
                        String[] multiplesIdentificadores = identificador.split(",");
                        for (String id : multiplesIdentificadores) {
                            id = id.trim();
                            String errorDescripcion = Validar.validarIdentificador(id);
                            if (errorDescripcion != null) {
                                String error = "Error 300. Línea " + lineNumber + ". " + errorDescripcion;
                                errores.add(error);
                            }
                        }
                    } else {
                        String errorDescripcion = Validar.validarIdentificador(identificador);
                        if (errorDescripcion != null) {
                            String error = "Error 300. Línea " + lineNumber + ". " + errorDescripcion;
                            errores.add(error);
                        }
                    }
                }

                String inputError = Validar.validarInput(line);
                if (inputError != null) {
                    String error = "Error 400. Línea " + lineNumber + ". " + inputError;
                    errores.add(error);
                }

                lineNumber++;
            }

            if (!errores.isEmpty()) {
                logGenerator.escribirErroresAlFinal(errores);
            }
            logGenerator.escribirTokens(tokenCounts);
            logGenerator.escribirComentariosFinal(comentarioCount);

        } catch (IOException e) {
            System.out.println("Error procesando el archivo: " + e.getMessage());
        }
    }
}
