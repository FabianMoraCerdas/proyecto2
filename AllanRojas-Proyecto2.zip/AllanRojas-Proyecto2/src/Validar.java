import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validar {
    private static Hashtable<String, Boolean> palabrasReservadas = new Hashtable<>();

    static {
        String[] reservadas = {
            "False", "None", "True", "and", "as", "assert", "async", "await", "break", 
            "class", "continue", "def", "del", "elif", "else", "except", "finally", 
            "for", "from", "global", "if", "import", "in", "is", "lambda", 
            "nonlocal", "not", "or", "pass", "raise", "return", "try", 
            "while", "with", "yield"
        };
        for (String palabra : reservadas) {
            palabrasReservadas.put(palabra, true);
        }
    }

    public static String validarIdentificador(String identificador) {
        if (palabrasReservadas.containsKey(identificador)) {
            return "El identificador es inválido porque es una palabra reservada.";
        }
        if (Character.isDigit(identificador.charAt(0))) {
            return "El identificador es inválido porque comienza con un número.";
        }
        Pattern pattern = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_]*$");
        Matcher matcher = pattern.matcher(identificador);
        if (!matcher.matches()) {
            return "El identificador contiene caracteres no permitidos.";
        }
        return null;
    }

    public static String validarInput(String linea) {
        String regex = "^[a-zA-Z_][a-zA-Z0-9_]*\\s*=\\s*input\\(\".*\"\\)\\s*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(linea.trim());
        if (!matcher.matches()) {
            return "Error en la estructura del comando input.";
        }
        return null;
    }
}
